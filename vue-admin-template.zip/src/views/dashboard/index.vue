<template>
  <div class="dashboard-container">
    <div class="dashboard-text">首页</div>
    <input
      type="file"
      accept="image/jpg,image/jpeg,image/png,image/gif"
      @change="handleChange"
    />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
// 腾讯云对象存储
import COS from 'cos-js-sdk-v5'
var cos = new COS({
  SecretId: 'AKID2tVs0tXv4yd2C6lBMHxNYUAbPyIMBk48',
  SecretKey: 'sUrzsVt2wc2D8oFRN3VhjV1IK7ewznL6'
})
console.log(cos)
export default {
  name: 'Dashboard',
  computed: {
    ...mapGetters([
    ])
  },
  methods: {
    handleChange (e) {
      console.dir(e.target)
      cos.putObject({
        Bucket: 'xlj-1313062346', /* 必须 */
        Region: 'ap-shanghai', /* 存储桶所在地域，必须字段 */
        Key: 'xlj', /* 必须 腾讯云本地桶要创建的文件名称 自定义 */
        StorageClass: 'STANDARD',
        Body: e.target.files[0], // 上传文件对象
        onProgress: function (progressData) {
          console.log(JSON.stringify(progressData))
        }
      }, function (err, data) {
        console.log(err || data)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
